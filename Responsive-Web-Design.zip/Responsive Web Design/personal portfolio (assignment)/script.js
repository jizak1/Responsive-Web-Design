const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer({ alpha: true });
renderer.setSize(window.innerWidth, window.innerHeight);
document.querySelector('#welcome-section').prepend(renderer.domElement);

const geometry = new THREE.BufferGeometry();
const vertices = [];
const colors = [];
const cyberpunkColors = [
	new THREE.Color(0xff2a6d), 
	new THREE.Color(0x05d9e8), 
	new THREE.Color(0x7700ff)  
];

for (let i = 0; i < 5000; i++) {
	vertices.push(
		Math.random() * 2000 - 1000,
		Math.random() * 2000 - 1000,
		Math.random() * 2000 - 1000
	);
	const color = cyberpunkColors[Math.floor(Math.random() * cyberpunkColors.length)];
	colors.push(color.r, color.g, color.b);
}

geometry.setAttribute('position', new THREE.Float32BufferAttribute(vertices, 3));
geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

const particles = new THREE.Points(
	geometry,
	new THREE.PointsMaterial({
		size: 3,
		vertexColors: true,
		transparent: true
	})
);
scene.add(particles);
camera.position.z = 1000;

function animate() {
	requestAnimationFrame(animate);
	particles.rotation.x += 0.0005;
	particles.rotation.y += 0.0005;
	renderer.render(scene, camera);
}
animate();

window.addEventListener('resize', () => {
	camera.aspect = window.innerWidth / window.innerHeight;
	camera.updateProjectionMatrix();
	renderer.setSize(window.innerWidth, window.innerHeight);
});