AOS.init({
	duration: 1000,
	once: true
});

// Smooth scroll for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
	anchor.addEventListener('click', function (e) {
		e.preventDefault();
		document.querySelector(this.getAttribute('href')).scrollIntoView({
			behavior: 'smooth'
		});
	});
});

// Header scroll effect
let lastScroll = 0;
window.addEventListener('scroll', () => {
	const currentScroll = window.pageYOffset;
	const header = document.getElementById('header');
	
	// Scroll down
	if (currentScroll > lastScroll && currentScroll > 80) {
		header.style.transform = 'translateY(-100%)';
	}
	// Scroll up
	else {
		header.style.transform = 'translateY(0)';
	}
	
	lastScroll = currentScroll;
});

// Form submission handling
document.getElementById('form').addEventListener('submit', function(e) {
	e.preventDefault();
	const email = document.getElementById('email').value;
	// Here you would typically handle the form submission
	console.log('Form submitted with email:', email);
	// Clear the form
	this.reset();
});