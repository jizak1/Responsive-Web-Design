document.addEventListener('DOMContentLoaded', () => {
	const navLinks = document.querySelectorAll('.nav-link');
	navLinks.forEach(link => {
		link.addEventListener('click', (event) => {
			event.preventDefault();
			const targetId = link.getAttribute('href').substring(1);
			const targetElement = document.getElementById(targetId);
			targetElement.scrollIntoView({ behavior: 'smooth' });

			navLinks.forEach(l => l.classList.remove('active'));
			link.classList.add('active');
		});
	});

	const scrollTopBtn = document.createElement('button');
	scrollTopBtn.innerHTML = '↑';
	scrollTopBtn.classList.add('btn-scroll-top');
	document.body.appendChild(scrollTopBtn);

	scrollTopBtn.addEventListener('click', () => {
		window.scrollTo({ top: 0, behavior: 'smooth' });
	});

	window.addEventListener('scroll', () => {
		scrollTopBtn.style.display = window.scrollY > 200 ? 'block' : 'none';
	});
});